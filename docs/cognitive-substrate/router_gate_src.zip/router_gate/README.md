# router_gate — complexity-aware model router + assumption/uncertainty gate

A runnable prototype of two mechanisms from *A Cognitive Substrate for Coding Agents*
(Theory → Evidence → Build-Map edition):

- **M1 — Complexity-aware routing** (`router.py`): a deployed LLM is a probability
  engine billed per token. Sending a trivial task (`is_prime(n)`) to a premium model
  is pure waste. The router scores a task's intrinsic complexity with a **transparent,
  attributable rubric** and sends it to the cheapest capable tier, escalating only on a
  failed external check.
- **M2 — Assumption / uncertainty gate** (`gate.py`): the root failure named by the
  project — *"the biggest problem is Assumption. If it doesn't have enough context it
  will assume many things."* When the context under-determines the task, a frozen LLM
  fills the gap with a confident guess. The gate scores **specification completeness**
  and, when a request is under-specified, **halts and asks** instead of confabulating.

The two compose into one decision loop (`pipeline.py`):

```
request → ① assumption gate → (halt & ask │ ② route → ③ execute → ④ verify → escalate)
```

## Why it is built this way

The project's core discipline is: *AI output is mathematically-calculated probability,
non-deterministic, never blindly trusted.* Two design commitments follow directly:

1. **Every decision is a transparent rubric, not another opaque model call.** The router
   and gate do **not** ask a second LLM "how hard is this?" or "is this specified?" —
   that would just move the untrusted probability up a level. Every point of every score
   is attributed to a named feature you can audit and override (`decision.explain()`).
2. **Trust is earned by an external check, never asserted by the model.** Escalation is
   driven by a caller-supplied verifier (a test, a compile, a regex) — the same move the
   paper makes at the architecture level, applied to a single request.

This mirrors the Qur'anic lens the paper uses as design framing: *tabayyun* — verify a
report before acting on it (49:6); and do not pursue what you lack knowledge of (17:36).

## Run it

```bash
pip install -r requirements.txt      # only pytest is needed; stdlib otherwise
python demo.py                       # offline, no tokens spent
python -m pytest                     # 19 tests
python evaluate.py                   # offline evaluation over the 30-task set
python evaluate.py --live            # real host.llm calls (Claude Science kernel only)
```

## What the evaluation shows (live, real models)

Run on the actual tier ladder — cheap=`claude-haiku-4-5`, mid=`claude-sonnet-5`,
premium=`claude-opus-4-8` — over a 30-task set:

| Metric | Result |
|---|---|
| Gate accuracy (should-ask) | 30/30 · precision 1.00 · recall 1.00 |
| Routing accuracy (well-specified tasks) | 21/21 exact tier |
| **Real cost saved vs always-premium** | **62.1%** (same measured tokens, cheaper tiers) |
| Execution-verified sub-experiment | 3/3 routed-down outputs passed real test cases |

### Honest limits of this result

- The 30-task set is **hand-labeled and small**, and the rubric thresholds were tuned
  against it. Perfect accuracy shows the rubric **can separate** these cases — it is a
  **demonstration, not a benchmark**, and does not estimate field accuracy.
- Cost figures are exact arithmetic on **real measured token counts** and *approximate*
  public list prices; the mechanism's value is the ratio between tiers, not the exact $.
- The complexity signals and gate dimensions are English- and code-keyword heuristics.
  A production version would calibrate thresholds on a large, held-out task distribution
  and likely learn the rubric weights rather than hand-set them.

## Files

```
router_gate/
  router.py     M1 — complexity scoring + tier banding (transparent rubric)
  gate.py       M2 — specification-completeness scoring + clarifying questions
  pipeline.py   the composed gate→route→execute→verify→escalate loop
  pricing.py    tier ladder + token→cost arithmetic
  taskset.py    30 hand-labeled tasks (gold tier + gold should-ask)
demo.py         offline walkthrough
evaluate.py     offline/live evaluation harness
tests/          19 unit tests
requirements.txt
conftest.py     makes `pytest` work with zero setup
```
