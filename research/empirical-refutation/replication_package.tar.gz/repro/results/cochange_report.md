# Impact Oracle vs. Real Co-Change History: An Independent Evaluation

**Status: NEGATIVE RESULT.** The Impact Oracle's headline claim of perfect recall (README:
"Precision=0.633, **Recall=1.000**, F1=0.753" on a 5-mutation self-built demo package) does
**not** survive contact with real-world commit history. On 759 evaluated files across 9
independently-selected OSS Python repositories, pooled micro-averaged recall peaks at
**2.20%** (95% bootstrap CI [1.20%, 3.31%]) — not 100%. This is the result we are reporting,
per the governing instruction that a real negative finding is a publishable success of this
evaluation track, not a failure of it.

This document follows the frozen [pre-registration](#pre-registration-and-corpus) exactly.
Every threshold, filter, and sampling seed below was fixed before any repository was cloned.

---

## 1. Headline result

| | Oracle (best grid threshold) | Oracle (shipped default, t=0.10) | Grep baseline | Edited-file-only |
|---|---|---|---|---|
| **Recall** | 0.0220 [0.0120, 0.0331] | 0.0175 [0.0099, 0.0267] | 0.5732 [0.5408, 0.6036] | 0.0000 (by construction) |
| **Precision** | 0.3982 [0.2709, 0.5653] | 0.3813 [0.2514, 0.5861] | 0.3535 [0.3250, 0.3820] | 0.0000 (by construction) |
| **F1** | 0.0416 [0.0232, 0.0616] | 0.0335 [0.0192, 0.0504] | 0.4373 | 0.0000 |

*Pooled, micro-averaged over all 759 evaluated files, 9 repos. 95% CIs from 2000-resample
file-level bootstrap, seed 1234. "Best grid threshold" = 0.02, the lowest value in the
pre-registered sweep — i.e. the single most favorable point for the oracle's recall, and it
is still 2.2%.*

The grep baseline — a simple text search for symbol names, no dependency graph, no
confidence model — beats the oracle on every metric except precision-at-best-threshold. This
is the opposite of what a "codebase world model" is supposed to buy over an unstructured
baseline.

![Per-repo precision/recall/F1 with bootstrap CIs]({{artifact:art_858ae4dd-a54d-4e34-98c9-e5bb1c27a6bc}})

### The per-file recall distribution (not just the mean)

The task asked explicitly whether recall "stays at/near 1.00" — the mean alone can hide a
bimodal reality, so here is the full distribution at threshold 0.02, n=759 files:

| Statistic | Value |
|---|---|
| Mean | 0.0163 |
| Median | **0.0000** |
| Q1 / Q3 | 0.0000 / 0.0000 |
| Files with recall = 0.0 (misses **every** co-changed file) | **691 / 759 (91.0%)** |
| Files with recall = 1.0 (catches **all** co-changed files) | 1 / 759 (0.13%) |

Recall is not merely low on average — it is a step function that sits at exactly zero for
91% of files. This is the opposite of "near 1.00."

![Confidence-threshold sweep, pooled]({{artifact:art_ad7cd842-1b01-482c-8533-277b0a20eedf}})

---

## 2. Per-repo detail

| Repo | n files | n GT pairs | Oracle R | Oracle P | Oracle F1 | Grep R | Grep P | Grep F1 | GT ceiling* |
|---|---|---|---|---|---|---|---|---|---|
| psf/requests | 33 | 502 | 0.004 | 1.000 | 0.008 | 0.526 | 0.591 | 0.556 | 0.873 |
| pallets/flask | 61 | 1188 | 0.000 | 0.000 | 0.000 | 0.633 | 0.492 | 0.554 | 0.983 |
| pallets/click | 62 | 1100 | 0.000 | 0.000 | 0.000 | 0.461 | 0.481 | 0.471 | 0.976 |
| pallets/jinja | 46 | 894 | 0.000 | 0.000 | 0.000 | 0.677 | 0.591 | 0.631 | 0.998 |
| Textualize/rich | 143 | 4526 | 0.077 | 0.418 | 0.130 | 0.551 | 0.420 | 0.476 | 0.946 |
| encode/httpx | 60 | 1910 | 0.019 | 0.900 | 0.037 | 0.463 | 0.813 | 0.590 | 0.973 |
| python-attrs/attrs | 50 | 726 | 0.000 | 0.000 | 0.000 | 0.631 | 0.437 | 0.516 | 0.942 |
| pytest-dev/pytest | 200 | 5910 | 0.000 | 0.000 | 0.000 | 0.665 | 0.281 | 0.395 | 0.981 |
| Delgan/loguru | 104 | 1874 | 0.013 | 0.155 | 0.024 | 0.419 | 0.191 | 0.263 | 0.990 |

*GT ceiling = the maximum recall any purely-static-dependency-graph tool could achieve on
this ground truth (1 − share of false negatives with no static path in either direction,
within 10 hops). See §4.

Full per-threshold tables (all 17 grid points, all 9 repos, with CIs) are in
`cochange_results.json`.

---

## 3. A critical diagnostic: most of the collapse is a fixable bug, not a fundamental limit

Six of the nine repos show recall of **exactly 0.0000** at every threshold. That is extreme
even given the headline finding, so it was investigated directly rather than reported as an
unexplained curiosity.

**Root cause, verified three independent ways** (minimal networkx reproduction, direct
source inspection, cross-repo quantification): `WorldModel` derives each module's qualified
name from its file path *relative to the codebase root*. In a **src-layout** package
(`src/pkgname/...`), that produces names prefixed `src.pkgname....`. But code elsewhere in
the same repository legitimately writes **absolute imports without the `src.` prefix**
(e.g. `pytest-dev/pytest`'s `testing/test_setuponly.py:7`: `from _pytest.pytester import
Pytester` — correct at actual Python runtime, since `src/` is on `sys.path`). NetworkX's
`graph.add_edge()` auto-creates a placeholder node for this unprefixed target with an
**empty metadata dict**. The shipped `_merge_phantom_nodes()` method exists specifically to
merge exactly this pattern — its own docstring describes this scenario almost verbatim — but
its guard clause (`if v in existing: continue`) checks node *presence*, and `add_edge()` has
already made the phantom "present" (with no data) by the time the merge logic runs. The
resolution is silently skipped for every case it was written to handle.

This is a graph-**construction** defect, fully orthogonal to `decay`, `EDGE_WEIGHTS`,
`max_hops`, or the confidence threshold — none of which were touched.

| Repo | Layout | Recall, as shipped | Recall, after 1-line world-model fix |
|---|---|---|---|
| Textualize/rich | flat-layout | 0.0767 | 0.4456 |
| psf/requests | src-layout | 0.0040 | 0.3725 |
| pallets/flask | src-layout | 0.0000 | 0.3603 |
| pytest-dev/pytest | src-layout | 0.0000 | 0.3355 |
| pallets/click | src-layout | 0.0000 | 0.2927 |
| pallets/jinja | src-layout | 0.0000 | 0.2785 |
| python-attrs/attrs | src-layout | 0.0000 | 0.2438 |
| encode/httpx | flat-layout | 0.0188 | 0.2351 |
| Delgan/loguru | flat-layout | 0.0128 | 0.0651 |
| **Pooled** | — | **0.0220** | **0.3185** |

Repairing only this defect raises pooled recall **14.5×**, from 2.2% to 31.9% — and the
correlation with package layout is exact: all three flat-layout repos (rich, httpx, loguru —
package *is* the repo root, so no prefix mismatch is structurally possible) already had the
corpus's only non-negligible recall; every src-layout repo (the other 6) sat at ≤2%.

![As-shipped vs. repaired recall by repo layout]({{artifact:art_ea27e75f-d0f9-4f43-a198-8243b6719489}})

**This diagnostic measurement was not substituted for the primary result.** §1's numbers are
the oracle exactly as shipped, per the pre-registration's freeze on internal hyperparameters.
The repair is reported separately, clearly labeled, to bound how much of the collapse is an
easily-fixable implementation bug versus a deeper limitation — because conflating the two
would misdirect any follow-up work. It is not: even after repairing it, pooled recall (31.9%)
remains far short of "perfect," and cross-tabulating against the failure-mode categories below
shows the fix resolves only 30.3% of all false negatives (5,525/18,221) — overwhelmingly (97.8%
of what it fixes) cases that were *also* the sibling-dependency pattern described next. The
majority of that pattern (11,845 of 17,251 sibling cases) is untouched by this fix and needs a
separate algorithmic change.

---

## 4. Failure modes (Step 4), counted, on the as-shipped oracle

At the lowest grid threshold (0.02, the most favorable point), pooling all 9 repos gives
**18,221 false negatives** — co-changed files the oracle assigns zero confidence to at all.
Every one was categorized structurally (via networkx reachability on the oracle's own graph,
not by eyeballing), in three mutually exclusive buckets:

| Category | Count | Share | What it means |
|---|---|---|---|
| **Sibling common dependency** | 17,251 | **94.7%** | A static path exists, but only via a *mixed-direction* route (both files depend on a shared third symbol). The oracle's pure reverse-BFS structurally cannot traverse this. |
| **Forward-only blind spot** | 389 | 2.1% | Reachable only in the *forward* (successor) direction — by design, the oracle never looks there. |
| **No static path at all** | 581 | **3.2%** | Ground-truth limit: no dependency edge connects the two files in either direction within 10 hops, at all. This bounds the *maximum* recall any static-analysis tool could reach on this data. |

**The headline number from this table:** of all the recall the oracle is missing, only 3.2%
is a hard ceiling imposed by the ground truth itself. The other 96.8% is reachable in the
oracle's *own graph* — it is an algorithm limitation, not a modeling-approach limitation.
Pooled, the oracle achieves 2.2% recall against a same-graph ceiling of **96.9%** — **2.3% of
its own theoretical maximum.**

**Concrete example (sibling pattern):** in `pallets/flask`, changing `src/flask/__init__.py`
never surfaces `src/flask/json/__init__.py` as impacted, even though both modules import the
stdlib `json` module (`src.flask -> json`, kind=`imports`; `src.flask.json.load -> json`,
kind=`references`, confidence=0.8). Both are one hop from a common node; reverse-BFS from
`src.flask`'s symbols walks *predecessors* of `json`, never its other *successors*. A random
400-pair sample of this category shows 82.2% sit at exactly this minimum non-trivial distance
(undirected hop=2) — a single shared dependency, not a graph-connectivity artifact (the
underlying undirected graphs are 97.4–100% single-component across the corpus, so "some path
exists" alone would be unremarkable; what matters is these paths sit at the shortest possible
non-adjacent distance, meaning a bounded bidirectional extension to the traversal would
recover the large majority).

### Sub-categorizing the true ground-truth limit (the 581 "no static path" pairs)

Per the pre-registered sampling rule (`random.Random(20260815).sample(pairs, min(30,n))` per
repo), 216 of the 581 pairs were inspected at the actual commit-diff level:

| Sub-category | Count | Share of sample |
|---|---|---|
| Test-fixture / config coupling | 121 | 56.0% |
| Unclassified semantic/temporal coupling | 52 | 24.1% |
| Dynamic dispatch (getattr/setattr/registry) | 40 | 18.5% |
| Release-chore coupling (verified version-string diffs) | 3 | 1.4% |

*(An earlier filename-only heuristic for release-chore coupling over-counted at 14.8% by
flagging any `__init__.py` touch; corrected to require an actual `__version__=` diff line
before any metric was computed — see `cochange_failure_modes.json` for the full before/after.)*

**Concrete dynamic-dispatch example:** `psf/requests`'s `src/requests/status_codes.py`
builds its entire public `codes` lookup via a loop of `setattr(codes, title, code)` calls —
there is no AST-visible reference to any individual status-code attribute name anywhere in
the codebase, so no static edge to this file can ever exist for a consumer of e.g. `codes.ok`.

### Over-warnings (false positives), at threshold 0.02

After correcting the evaluation harness to apply the pre-registered path-exclusion filter to
*predictions* as well as ground truth (§7, "implementation fixes made before reporting"), 618
false positives remain, pooled — and they are extremely concentrated:

| Repo | FP count | Share |
|---|---|---|
| Textualize/rich | 483 | 78.2% |
| Delgan/loguru | 131 | 21.2% |
| encode/httpx | 4 | 0.6% |
| *(other 6 repos)* | 0 | 0.0% |

78.2% of over-warned target files are test files; 23.0% of over-warnings originate from
`__init__.py`/`__main__.py` hub files. Manual inspection traces the pattern to widely-called
"core utility" symbols with genuinely high graph in-degree (`rich.cells.cell_len`: 14;
`rich.cells.CellTable`: 25; the `loguru` package `__init__`: 17) — the oracle is correctly
identifying real structural fan-in; the mismatch is that the bounded commit history mined for
ground truth does not show every structural dependent having actually been *edited* in
lockstep. This is an inherent ambiguity of co-change as an impact proxy (§5), not obviously
an oracle error.

---

## 5. Threats to validity

- **Co-change as a proxy for semantic impact, in both directions.** A file can co-change
  with another for reasons with no static dependency (a shared PR touching unrelated files,
  a release chore, test-fixture conventions — see §4's sub-categorization, which together
  account for the bulk of the true 3.2% ground-truth-limited share) — inflating what looks
  like an oracle miss. Conversely, a file can depend on another (and be flagged by the
  oracle) without ever having needed a synchronized edit in the mined history window — this
  is very likely the dominant explanation for §4's over-warnings, which concentrate almost
  entirely on high-fan-in utility symbols whose dependents simply haven't all been touched
  yet within this corpus's commit history.
- **Corpus selection bias.** All 9 repos are English-language, GitHub-hosted, star-popular
  (≥3000 stars), actively-maintained, English-speaking-maintainer OSS. This is a specific
  slice of the Python ecosystem (mature libraries with conventional structure) and may not
  represent internal/enterprise codebases, newer projects, or projects with less-disciplined
  commit hygiene.
- **Single-language scope.** Python only. The AST parser, import-resolution heuristics, and
  the specific src-layout defect identified in §3 are all Python-and-packaging-convention
  specific; none of this generalizes automatically to other languages.
- **Shallow-clone history truncation.** The pre-registration requested `--depth 3000`
  bounded clones; the corpus record's addenda (verified during this session — see below)
  note the server returned **full, untruncated history for all 9 final repos** (confirmed
  independently here: e.g. `pytest-dev/pytest`'s 6490-commit `psf/requests` check and
  17622-commit `pytest` check both showed `rev-list --count HEAD` matching the GitHub API
  estimate exactly, with 1612 merge commits correctly excluded by `--no-merges` for
  `requests` alone). This threat is noted per protocol but does not materially apply to this
  run — more signal was available, not less.
- **Mega-commit filter (threshold=20).** A judgment call, pre-declared before any repo was
  mined. 167 non-bot commits across the corpus sit within ±2 files of this boundary (61 in
  `pytest-dev/pytest` alone, reflecting its much larger commit volume) — commits just above
  or below are not qualitatively different in kind, so the specific cutoff has some
  arbitrariness, though it is applied identically everywhere.
- **Ground-truth mining independently re-verified.** This session independently re-cloned
  full history for all 9 repos and re-implemented the mining protocol (bot/merge/mega-commit
  filters, path exclusions, final-checkout restriction) from scratch, without reference to
  the provided ground truth's code. Result: **0 mismatches across all 801 rows** — every
  file, every impacted-file list, every count, identical. This is a strong (though not
  absolute — both implementations share the same written protocol and could share a blind
  spot) validation that the ground truth is not itself the source of the recall collapse.
- **The world-model defect (§3) is diagnostic, not confirmatory, for the remaining fix
  space.** Repairing it in isolation is a clean natural experiment for *this* bug, but
  interactions with the separate sibling-traversal fix (§4) were not evaluated — the two
  likely compound rather than add, and this session did not build or test that combined
  version, since doing so would mean evaluating a *different* oracle than the one specified
  for this track.

---

## 6. Pre-registration and corpus

This evaluation follows `PREREGISTRATION.md` (artifact `130a1e93`) exactly. That
document's own version history was checked for integrity before use: a v2 exists,
created 807 seconds after the v1 handed to this session, consisting **only** of three
dated, purely-additive addenda documenting the corpus-selection funnel (which candidates
failed the metadata screen, which failed post-clone structural sanity, and the
shallow-clone-came-back-full note) — zero characters above the original "End of
pre-registration" line were altered, exactly matching the document's own self-imposed rule.
No integrity concern.

**Final corpus (9 repos, all independently re-verified at their exact pinned clone SHAs by
`.py`-file-count match before evaluation began):** psf/requests, pallets/flask,
pallets/click, pallets/jinja, Textualize/rich, encode/httpx, python-attrs/attrs,
pytest-dev/pytest, Delgan/loguru.

**Corrections applied to the evaluation harness before any metric was computed (not
post-hoc tuning):**
1. Path-exclusion filter (`docs/examples/vendor/migrations/.github/benchmarks` and
   singular variants) was applied to oracle and grep *predictions*, per pre-registration
   §3.5's explicit requirement that the filter apply "to BOTH ends of every co-change pair
   AND LATER to oracle/grep predictions." This only removed spurious false positives (22%
   of raw oracle predictions, 6% of raw grep predictions, both entirely outside the ground
   truth's support by construction) — it did not change any true positive or false negative,
   so recall is completely unaffected; only precision moved (and only upward).
2. The release-chore-coupling sub-classifier (§4) was corrected from a filename-only
   heuristic (`__init__.py` matched anything) to require an actual `__version__=` diff line,
   after manual inspection of a sample flagged a false positive (an httpx API-surface
   refactor, not a version bump). Both versions are recorded in the underlying analysis; only
   the corrected one is reported as the headline sub-classification.

---

## 7. Deliverables

- `cochange_results.json` — full per-repo and pooled metrics across all 17 threshold-grid
  points, with 95% bootstrap CIs, plus the per-file recall distribution and the world-model
  diagnostic summary.
- `cochange_failure_modes.json` — full false-negative/false-positive categorization,
  diff-inspection sub-categorization, ground-truth-ceiling bound, and the complete
  world-model-defect diagnostic with cross-tabulation against the directional categories.
- `fig_cochange_results.png` — per-repo precision/recall/F1, oracle vs. grep vs.
  edited-file-only, with bootstrap CIs.
- `fig_threshold_sweep.png` — pooled precision/recall/F1 across the full confidence-threshold
  grid, with the ground-truth ceiling annotated.
- `fig_phantom_node_diagnostic.png` — as-shipped vs. world-model-repaired recall, by repo and
  package layout.
