# Pre-Registration: Impact Oracle Co-Change Evaluation

**Written and frozen BEFORE cloning any repository, before mining any commit, and before
running the oracle on any real data.** Every threshold, filter, and sampling rule below is
fixed now. If any downstream number looks bad, the FIX is to report it, not to edit this file.
(Any correction found necessary later — e.g. a metadata query fails — will be appended as a
dated addendum, never a silent edit of the numbers below.)

Timestamp: 2026-08-15 (session date). Task: independent empirical evaluation of the Impact
Oracle prototype's blast-radius predictions against real-world co-change history.

---

## 1. Corpus selection criteria (applied mechanically to metadata, before cloning)

A candidate repository is ELIGIBLE iff ALL of the following hold, checked via the GitHub REST
API and the repo's own reported stats:

1. **Language purity**: Python bytes / total bytes (from `/repos/{o}/{r}/languages`) >= 0.85.
2. **Stars**: `stargazers_count` >= 3000 (proxy for real-world usage / maturity).
3. **Contributors**: approx. contributor count (via paginated `/contributors` Link-header probe,
   `per_page=1`) >= 50.
4. **Commit volume**: approx. total commit count on the default branch (via paginated
   `/commits` Link-header probe, `per_page=1`) >= 800.
5. **Age**: `created_at` at least 5 years before today (2026-08-15) — i.e. created on or before
   2021-08-15.
6. **Active maintenance**: `pushed_at` within the last 24 months (on or after 2024-08-15).
7. **Not a monorepo giant**: `size` (KB, from the API) < 500,000 KB (excludes CPython/Django-
   scale repos that would make shallow history mining intractable at our depth bound).
8. **No involvement from this project**: repo owner/org is not the user (GitHub identity
   `CodeWithJuber`) and is not one of this project's own repos (forgekit, hikmah-stack,
   wisdom-lens, cognitive-substrate materials). All candidates below are long-established,
   independently-maintained third-party OSS projects, so this is expected to hold trivially.
9. **Structural sanity** (checked post-clone, not outcome-based): >= 15 `.py` files in the
   final checkout, excluding the path-exclusion set in Section 3.

Selection is capped at **15 repositories**, target **12**, spanning size and domain as follows.
Candidates are tried in the PRIMARY order below; a candidate that fails any criterion above is
dropped and replaced by the next unused BACKUP, in order, with the substitution logged verbatim
in `cochange_corpus.json`. No repository is ever added or removed after Step 3 (evaluation)
begins, and no substitution is ever made in response to oracle/grep/baseline performance —
only in response to the metadata checks in this section.

**Primary candidates (12), by domain:**
| # | slug | domain |
|---|------|--------|
| 1 | psf/requests | HTTP client |
| 2 | pallets/flask | web microframework |
| 3 | pallets/click | CLI framework |
| 4 | pallets/jinja | templating engine |
| 5 | Textualize/rich | terminal rendering |
| 6 | encode/httpx | async HTTP client |
| 7 | python-attrs/attrs | class boilerplate / data modeling |
| 8 | pytest-dev/pytest | testing framework |
| 9 | pytest-dev/pluggy | plugin system |
| 10 | tqdm/tqdm | progress bars |
| 11 | executablebooks/markdown-it-py | markdown parser |
| 12 | dateutil/dateutil | date/time utilities |

**Backup candidates (4), tried in this order if a primary fails eligibility:**
| # | slug | domain |
|---|------|--------|
| B1 | more-itertools/more-itertools | iterator utilities |
| B2 | pypa/packaging | packaging utilities |
| B3 | Delgan/loguru | logging |
| B4 | agronholm/typeguard | runtime type checking |

## 2. Clone protocol

- `git clone --depth 3000 --no-single-branch <url>` per repo (bounded shallow clone; if a
  repo's true history is shorter than 3000 commits, this simply retrieves full history).
- If depth-limited clone fails for any reason, fall back to `--depth 1000`, then full clone;
  record which was actually used.
- Record: exact `HEAD` commit SHA after clone, whether `.git/shallow` exists (truncated
  history flag), and `git rev-list --count HEAD` (commits actually retrieved, which may be
  less than the true total commit count if the shallow boundary was hit).
- The oracle's WorldModel and all ground-truth relative file paths use the **repo root**
  (the clone directory itself) as the common reference frame — this is the same root git
  reports paths relative to, so no path-remapping is needed regardless of `src/`-layout vs
  flat layout.

## 3. Ground-truth mining protocol (`git log --name-only --no-merges`)

Pre-declared filters, applied identically to every repo:

1. **Merges excluded**: `--no-merges` on the `git log` invocation.
2. **Bot commits excluded**: commits whose author name OR email contains (case-insensitive)
   any of `bot`, `dependabot`, `pre-commit-ci`, `renovate`.
3. **Mega-commit threshold**: a commit touching **> 20 files of any type** (not just `.py`) in
   its `--name-only` listing is dropped ENTIRELY from ground-truth construction (formatting
   sweeps, vendored bumps, mass renames). Threshold = 20, chosen from the pre-suggested
   ~10-20 range, fixed before any repo is mined.
4. **File-type restriction**: only `.py` files participate in ground truth (as either the
   "changed" file or a co-change target).
5. **Path exclusions** (case-insensitive path-component match), applied to BOTH ends of every
   co-change pair and later to oracle/grep predictions: any path containing a component in
   `{docs, doc, examples, example, vendor, vendored, migrations, .github, benchmarks,
   benchmark}`. `tests`/`test` directories are DELIBERATELY NOT excluded — test-fixture
   co-change is one of the failure-mode categories Step 4 must quantify, so it must remain
   visible in ground truth.
6. **Minimum commit size for signal**: a commit must touch >= 2 distinct eligible `.py` files
   (after filters 1-5) to contribute any co-change pair; commits with 0 or 1 eligible `.py`
   file are counted in the funnel accounting but contribute no pairs.
7. **Ground truth definition**: for a commit touching eligible files {f1, ..., fk} (k>=2), every
   fi contributes to the ground-truth impact set of every fj (j != i) in that commit (symmetric,
   aggregated with counts across all qualifying commits in the repo's mined history).
8. **Final-checkout restriction**: ground truth is further restricted, at evaluation time (Step
   3), to pairs where BOTH files exist in the final checked-out tree at the recorded HEAD SHA —
   the oracle's WorldModel is built from a single current-tree snapshot and cannot represent
   deleted/renamed files. The count of pairs/files dropped by this restriction is reported
   separately in the funnel accounting (this is a known, declared LIMIT of applying a
   static-snapshot tool to historical co-change signal, not a hidden exclusion).

Funnel counts to record per repo: total commits retrieved, non-merge, non-bot, commits with
<=20 total files (post mega-commit filter), commits with >=2 eligible `.py` files (contribute
pairs), unique changed files with ground truth, and unique changed files with ground truth
AFTER the final-checkout restriction.

## 4. Evaluation protocol (Step 3)

- **Oracle's internal hyperparameters are NOT tuned.** `decay=0.85`, the shipped
  `EDGE_WEIGHTS` dict, and `max_hops=10` are used exactly as they ship in `oracle.py`. The
  only knob swept is the user-facing `threshold` parameter to `predict_impact`, which the
  README itself documents as a tunable output cutoff — sweeping it is the requested
  "confidence-threshold curve," not internal retuning.
- **Threshold grid** (fixed): `[0.02, 0.05, 0.08, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40,
  0.45, 0.50, 0.55, 0.60, 0.70, 0.80, 0.90]`.
- **File-level operationalization of the oracle** (the oracle's native API takes a symbol, not
  a file): for a changed file `f`, let `symbols(f)` = the module-level node for `f` plus every
  class/function/name node whose `file == f`. Compute `predict_impact(s, threshold=0.02)`
  (the lowest grid value) for every `s` in `symbols(f)` once; for a candidate file `g != f`,
  define `conf(f→g) = max` over `s` of the confidence with which `g` appears in that symbol's
  impacted-files list. For any higher threshold `t` in the grid, the predicted set is
  `{g : conf(f→g) >= t}`. This reuses one low-threshold BFS pass per symbol for the entire
  sweep rather than re-running BFS per threshold.
- **Grep file-baseline** (extending the shipped `ImpactOracle.grep_baseline`, which is
  symbol-scoped, to file granularity): predicted set for file `f` = union of
  `grep_baseline(name, root)` over `name` in {every function/class name defined at module or
  class level in `f`} ∪ {`f`'s module basename}, minus `f` itself. No threshold applies (grep
  is binary).
- **Edited-file-only baseline**: predicted "other files" set is always `{}` by construction
  (this baseline only ever names the file already known to be edited, which is excluded from
  the "other files" ground truth by definition). This yields a deterministic recall of exactly
  0.0 on every evaluated file and an undefined (0-denominator) precision — this determinism is
  an expected, declared property of the baseline under this ground-truth definition, not an
  error, and will be reported as such rather than redefined after the fact.
- **Compute-tractability sampling** (triggered by pre-known counts, not by outcomes): if a
  repo's post-filter unique-changed-file count exceeds 200, take
  `random.Random(20260815).sample(sorted(files), 200)`. If a file's `symbols(f)` exceeds 80,
  take `random.Random(20260815).sample(symbols, 80)`. Seed is fixed and dated, applied
  identically to every repo/file that exceeds the cap.
- **Scoring convention** for precision/recall/F1 edge cases (matches the shipped
  `evaluate.py` convention for continuity): if predicted and actual are both empty -> (1,1,1);
  if predicted is empty and actual is non-empty -> (0,0,0); if actual is empty and predicted
  is non-empty -> (0,0,0). Given the final-checkout + minimum-commit-size restrictions, every
  evaluated file has non-empty ground truth by construction, so the only edge case that can
  actually occur is "predicted empty, actual non-empty" (the edited-file-only baseline, always).
- **Micro vs macro averaging**: the PRIMARY precision/recall/F1 numbers (per-repo and pooled)
  are MICRO-averaged — true positives/false positives/false negatives are summed across all
  evaluated files before computing the ratio, so files with larger ground-truth sets are not
  down-weighted. Per-file recall is ADDITIONALLY reported as its own distribution (mean,
  median, quartiles, histogram) — this is the macro-style diagnostic the task requests
  ("report the actual distribution of per-file recall, not just the mean").
- **Bootstrap CIs**: resample evaluated FILES with replacement, B=2000 iterations, seed=1234.
  Per-repo CIs resample within that repo's file list; pooled CIs resample within the full
  cross-repo file list. Each bootstrap draw re-sums tp/fp/fn over the resampled files and
  recomputes micro P/R/F1; report the [2.5th, 97.5th] percentile as a 95% CI.

## 5. Failure-mode categorization (Step 4) — pre-declared categories

Every oracle FALSE NEGATIVE (ground-truth co-change file the oracle never assigns >0
confidence to, i.e. absent from its impacted-files list at the lowest grid threshold 0.02) is
categorized, in this fixed priority order, by inspecting the actual diff/source:

1. **No static path in the graph at all** (the co-changed file shares no import/call/inherit/
   reference edge with the changed file's symbols at any hop <= max_hops=10) — checked
   structurally via `networkx` reachability on the built graph, not by eyeballing.
2. Among files with NO static path, sub-categorized by inspecting a bounded random sample
   (`random.Random(20260815).sample(..., min(30, n))` per repo) of the underlying commit
   diffs for: **dynamic dispatch** (getattr/setattr/importlib/`__getattr__`/plugin
   entry-point/string-keyed registry patterns visible in either file), **test-fixture /
   config coupling** (one side is under `tests/`/`test/` or a fixture/config file),
   **release-chore coupling** (version bumps, changelog, `__init__.py` version strings),
   or **unclassified semantic/temporal coupling** (none of the above pattern-matches).
3. Files WITH a static path that the oracle still misses at threshold 0.02 (a genuine oracle
   miss, not a ground-truth limit) are counted separately from category 1-2 misses.

Oracle FALSE POSITIVES (files the oracle predicts at threshold 0.02 that never co-change in
any qualifying commit) are counted in aggregate as "over-warnings," with a bounded random
sample inspected for common patterns (same seed/cap as above).

## 6. Threats to validity to be written up (Step 5)

Co-change as a proxy for true semantic impact (both directions of error: co-change without
dependency, and dependency without co-change), corpus selection bias (English-language,
GitHub-hosted, star-popular, English-speaking-maintainer OSS skews toward certain coding
styles), single-language (Python-only) scope, shallow-clone history truncation (bounded depth
may exclude older co-change signal for very mature repos), and the mega-commit filter's
specific effect (threshold=20 is a judgment call; commits just above/below it are not
qualitatively different).

---
*End of pre-registration. Nothing below this line existed at the time the above was written.*
