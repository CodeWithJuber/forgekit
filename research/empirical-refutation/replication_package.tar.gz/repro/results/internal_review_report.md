# Review: "Static Impact Analysis Does Not Transfer: A Pre-Registered Refutation of Two LLM-Agent Reliability Mechanisms"

**Recommendation: Major revision.**

This is an unusually honest paper for the genre — the authors built two mechanisms, evaluated
them on data they did not construct, and reported that both collapsed. The pre-registration
discipline is real (I traced the freeze timestamps, the addendum trail, and the corpus
substitution log, and found no outcome-based tampering in the main co-change track). But the
paper's own repair and routing sections contain several factual errors and inconsistencies —
one of them (a reversed calibration-bin claim) is currently stated backwards relative to the
paper's own data and figure, and needs to be fixed before this can be trusted as a record of
what the underlying numbers say. None of what I found undermines the paper's central,
important claim (self-built demonstrations can dramatically overstate recall and F1); several
of them undermine the *secondary* claims made in service of the repair and routing sections.

## Summary of strengths (so the authors can tell signal from noise)

- The core refutation (recall 1.000 → 0.022, pooled over 759 files / 9 repos) is fully
  traceable to the supplied artifacts: I independently recomputed pooled precision/recall/F1
  from the raw tp/fp/fn counts in `cochange_results.json` for the oracle, the grep baseline,
  and the edited-file-only baseline, and every headline number in the abstract and Table 1
  matches to the reported precision.
- The corpus-selection funnel (12 primary candidates, 2 backups tried, 1 backup rejected on a
  pre-declared structural-sanity criterion, 9 final repos) is internally consistent across
  `PREREGISTRATION.md`, `cochange_corpus.json`, and the paper text, with no evidence of
  outcome-based substitution.
- The failure-mode decomposition (94.7% sibling / 2.1% forward-only / 3.2% no-static-path) is
  arithmetically correct (17,251 + 389 + 581 = 18,221, matching the stated pooled false-negative
  count) and is a genuinely useful diagnostic contribution regardless of the issues below.
- The paper discloses its own deviations as they occur (the path-exclusion-filter correction,
  the release-chore sub-classifier correction, the rejected "unsafe" phantom-node fix, the
  `temperature` API-parameter substitution) rather than silently absorbing them — this is the
  right instinct and is more transparent than most papers in this area.
- Reporting a grep baseline that beats the oracle by a wide margin, and leading the abstract
  with that fact rather than burying it, is a genuine act of intellectual honesty that a
  self-interested write-up would have been tempted to soften.

## What would block acceptance today

**The calibration-bin claim in §4 is stated backwards (Finding F03, blocking).** The paper
says "decision accuracy is 0.93 in the second-highest confidence bin but 0.50 in the highest,"
and uses this to argue the gate's confidence score has "a more damaging property than a low
score." I recomputed the bins two independent ways — directly from `heldout_results.json`'s
`calibration.framing_A_reliability` block, and by re-binning the 80 raw per-task rows myself
with `pandas.qcut` — and both agree with the paper's own `fig_heldout_calibration.png`: the
**highest** completeness bin (0.976–1.0, n=16) has accuracy 0.94, and the **second-highest**
bin (0.90–0.976, n=4) has accuracy 0.50. The bins are swapped in the prose. This matters
because the paper uses the (mis-stated) direction to support a specific, strong qualitative
claim about non-monotonicity being worse than low accuracy — and because the affected bin has
only 4 tasks, the underlying finding may not even be robust once correctly attributed. This is
the single most reviewer-visible error in the draft and must be fixed regardless of everything
else.

## Major concerns

**Threshold and multiplier selection favor the more flattering number at two separate points
in the repair section (F01, F05).** The abstract's "14.5×" construction-defect figure is the
*unsafe*, rejected diagnostic fix's multiplier; the paper's own applied, safety-vetted fix
achieves 11.0× (both numbers are in the supplied artifacts, and the discrepancy between them is
even pre-emptively explained in `repair_results.json` — so the authors know this, but the
abstract still leads with the bigger, not-applied number with no caveat). Separately, the
repaired oracle's held-out headline is reported at a *tuned* threshold (t=0.10, found via the
same 120-config grid search that set the other 8 parameters) while the as-shipped baseline is
explicitly reported at the canonical, pre-registered t=0.02. At the same canonical threshold,
the held-out F1 is 0.416, not the reported 0.428 — a modest instance of exactly the kind of
threshold shopping the paper's own framing exists to guard against. Neither of these changes
the substantive conclusion (repaired oracle beats grep either way), but both should be fixed on
principle, and a hostile reviewer will treat the pattern — two independent instances of "when a
choice existed, the more flattering variant was reported" — as evidence the repair section
needs a more skeptical second pass by the authors themselves.

**The cost-saving headline compares an ungated number to a gated one (F02).** Table 2 labels
both the tuned 62.1% and the held-out 2.8% "Cost saving (correctness-gated)," but the tuned
62.1% was computed with no correctness gating at all (confirmed directly in
`eval_results.json`, whose 30-task rows have no correctness field). The fair, ungated-to-ungated
comparison is 62.1% vs. ~59.5% — barely different — and the real story is that gating plus
distribution shift together drive the collapse to 2.8%. The paper's own held-out cost analysis
already computes both an ungated ("first-attempt") and a gated ("escalation-inclusive") framing;
the fix is to apply the same two framings to the tuned side rather than mixing one framing per
column.

**The static ceiling used throughout is measured on the tool being evaluated, and no
independence control is reported (F04).** 96.9% of ground-truth pairs are "statically
reachable" — but reachable in the graph the *as-shipped, admittedly-buggy* oracle builds. Fixing
just the construction defect makes 51 more pairs reachable, nudging the true ceiling to ~97.15%
by the paper's own numbers. More importantly, none of the artifacts contain a random-pair
(non-co-changed) connectivity control, so there is no way to rule out that the small codebases
here (35–246 files, max_hops=10, undirected) are simply well-connected in general — which would
make the "ceiling" partly a fact about graph density rather than about recoverable semantic
impact. This doesn't make the ceiling argument circular in the strict logical sense (it is not
computed *from* the recall numbers it bounds), but it is not fully independent of the artifact
under test either, and the paper's rhetoric ("the ceiling is measurable," "bounds every result
below") claims more independence than is actually established.

**The tuning/held-out split's "honesty" rests on an unverifiable, self-administered timeline
(F06).** `SPLIT_DECLARATION.json` and `FROZEN_PARAMETERS.json` were saved to the artifact store
roughly three seconds apart, and the split file's own claimed declaration time is about 100
minutes before its actual save time — there is no external or cryptographic barrier between
"declaring the split" and "freezing parameters after grid search," only the same session's word.
Compare this to the paper's main pre-registration, which has a materially larger and more
plausible gap (frozen ~07:12–07:26 UTC, evaluated no earlier than ~10:01 UTC). This doesn't mean
the split was violated — I found no evidence it was — but the paper currently presents "touched
exactly once, after freezing" with more confidence than a self-evaluation setting can actually
support, and this should be disclosed as a limitation of the self-evaluation format rather than
asserted as fact.

**No artifact-availability statement (F09).** For a paper whose main claimed contribution is a
reusable protocol, the absence of any data/code availability statement in six pages is a gap an
ICSE/FSE reviewer will flag on process grounds alone.

## Minor issues

- Table 1's shipped-default row (F1=0.034) doesn't reproduce from its own tp/fp/fn counts
  (recomputation gives 0.033); it matches computing F1 from already-rounded P/R instead of raw
  counts (F08). Rounding-order bug, not a substantive error, but worth a pass over every table.
- The repair section's "66.8% of the static ceiling" for the held-out result divides by the
  pooled 9-repo ceiling rather than a held-out-specific one; using the latter gives 66.2% (F11).
- Contribution #1 claims the pre-registered protocol as the main transferable contribution, but
  the related-work section never engages with the existing Registered Reports / open-science
  literature in software engineering, so this specific claim is not benchmarked against prior
  art the way the paper's other four contributions are (F07).
- The project's own novelty assessment (`novelty_assessment.json`) covers composition-law and
  mechanism-design claims that live in a separate "extended version," not the claim (the
  protocol) that this venue paper actually leads with (F12).
- The grep baseline's exact string-matching semantics (word-boundary vs. substring) aren't
  documented in the paper (F10, nitpick) — I did not have time to verify this against source in
  this pass; see below.

## Novelty and scooping (point 5 of the brief)

I verified via web search that both cited preprints exist and match the paper's characterization
of them. Aksu's "Odds Law" (arXiv:2606.15712, submitted 14 Jun 2026) develops a decomposition
algebra with a verification-odds law and a k-gate geometric-amplification result, and its
companion "Maestro Order" (arXiv:2606.23983, submitted 22 Jun 2026) compiles the same
primitives into an orchestration harness with a worked coder/test-suite case study — both
consistent with what the paper says they show. The concession ("we concede priority... What our
framing retains is narrower") reads as adequate for the composition-law material specifically.
However, this concession concerns material that is not the venue paper's own headline
contribution (the protocol) — see F07/F12 above — so the *paper actually in front of a
reviewer* is not meaningfully weakened by the scooping on the composition law, provided the
paper doesn't lean on that law as a selling point beyond what §6 already concedes (it doesn't,
in the visible 6pp text).

## Venue fit and scope (point 7)

Six pages plus references is reasonable for a negative-results/replication paper at this venue.
The section structure (Protocol → Eval I → Failure Modes → Eval II → Repair → Threats → Related
Work → Discussion → Conclusion) covers what a reviewer would expect, though there is no explicit
RQ1/RQ2 framing, which some SE venues require explicitly. The threats-to-validity section is
genuinely good — it names co-change's bidirectional proxy error, corpus selection bias, single
language/ecosystem scope, and states plainly that no multiple-comparison correction was applied
because the comparisons are descriptive. The missing artifact-availability statement (F09) is
the one structural omission I'd flag as a process-level gap.

## Writing (point 8)

The prose is generally well-calibrated and avoids the most common overclaiming patterns — "What
we do not claim" is a good paragraph, and hedges like "we think" and "on this evidence" are used
appropriately rather than as evasions. The exceptions are the specific factual errors above: the
calibration-bin sentence (F03) currently makes a stronger and differently-directed claim than
the data supports, and the abstract's unqualified "14.5×" (F01) is stronger than what the
paper's own applied fix delivers. Fixing both would bring the prose back in line with the
paper's otherwise-good discipline about not overstating results.

## Not verified in this review

Time and scope constraints meant the following attack lines from the brief were not completed
and should not be treated as either confirmed or refuted:

- **Grep baseline implementation fairness at the source level.** I confirmed the *definition*
  in the pre-registration (extending the shipped `grep_baseline` symbol search to file
  granularity, no threshold) is reasonable on its face, but did not inspect the actual
  `oracle.py`/`impact_oracle_v2_src.zip` source to verify the string-match semantics (word
  boundary vs. substring) or hand-check a sample of grep's true/false positives against the
  ground truth. A stronger baseline (e.g., an import-only static graph with no confidence decay)
  was not constructed or estimated.
- **Independent re-derivation of the co-change ground truth from raw commit history.** The
  paper's claim of an independent re-mining match (801/801 rows) is internally consistent across
  artifacts but was not re-verified from scratch by cloning the 9 repositories myself.
   - **Full read of `impact_oracle_v2_src.zip` and the repaired source diff** referenced in the
  repair section's `CHANGES.md` (the phantom-node merge fix, the sibling in-degree cap, and the
  13 new tests) — I read the JSON *summaries* of these (`repair_results.json`, frozen parameters)
  but not the underlying code.
- **Router/gate source (`router_gate_src.zip`) inspection** to confirm the held-out evaluation
  truly never touched `router.py`/`gate.py` — I relied on the artifact's own attestation
  (`heldout_results.json` meta.thresholds_unchanged_note) rather than diffing the shipped zip
  against a known-good copy of the tuned-evaluation source.
- **PDF-vs-LaTeX rendering cross-check** for pages 4–6 (Discussion, Conclusion, Related Work,
  refs) — I read the compiled PDF pages 1–3 visually and the LaTeX source in full, but did not
  do a second visual pass on pages 4–6 against the source to catch compilation-only artifacts
  (overfull hboxes, mis-rendered tables).

None of these gaps point to a suspected problem — they are simply lines of attack the brief
requested that this pass did not reach. A follow-up review pass should prioritize the grep
baseline source inspection and the router/gate source diff, since those are the two places a
skeptical reviewer is most likely to probe next and where the current review has the least direct
evidence (only self-reported attestations, not independent verification).

## Recommendation

**Major revision.** The central finding (self-built demonstrations overstate recall/F1 by an
order of magnitude or more, and a trivial grep baseline beats a graph-based oracle) is well
supported and important, and I would not want the fixes below to be read as undermining it. But
F03 (reversed calibration claim) is a factual error load-bearing for a specific rhetorical point
and must be corrected; F02, F05, and F06 each involve a place where the more flattering of two
available framings was reported without adequate disclosure, and together they read as a
pattern a careful reviewer will notice and hold against the repair section specifically (not the
refutation, which remains solid). Fix the calibration sentence, rebalance the cost-saving
comparison, either match the as-shipped/repaired thresholds or disclose the threshold as a 9th
tuned parameter, disclose the split-timing limitation, and add an artifact-availability
statement — none of these require new experiments, only recomputation, relabeling, and honest
caveats using data the authors already have.
